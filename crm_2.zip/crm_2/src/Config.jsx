export const serverUrl = ``
export const serverApiUrl = `${(serverUrl)}/api`
