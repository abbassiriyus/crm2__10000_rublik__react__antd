const BaseTab = (title, ...rows) => {
    return {
        [title]: rows
    }

}

export default BaseTab;