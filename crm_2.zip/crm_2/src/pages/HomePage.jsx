import MainTable from '../components/MainTable/MainTable.jsx'
const HomePage = () => {
    return (
        <div>
            <MainTable />
        </div>
    )
}

export default HomePage
